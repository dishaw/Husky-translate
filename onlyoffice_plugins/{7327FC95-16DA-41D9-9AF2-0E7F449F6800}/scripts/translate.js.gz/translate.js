/*
 * (c) Copyright Ascensio System SIA 2010
 *
 * This program is a free software product. You can redistribute it and/or
 * modify it under the terms of the GNU Affero General Public License (AGPL)
 * version 3 as published by the Free Software Foundation. In accordance with
 * Section 7(a) of the GNU AGPL its Section 15 shall be amended to the effect
 * that Ascensio System SIA expressly excludes the warranty of non-infringement
 * of any third-party rights.
 *
 * This program is distributed WITHOUT ANY WARRANTY; without even the implied
 * warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR  PURPOSE. For
 * details, see the GNU AGPL at: http://www.gnu.org/licenses/agpl-3.0.html
 *
 * You can contact Ascensio System SIA at 20A-6 Ernesta Birznieka-Upish
 * street, Riga, Latvia, EU, LV-1050.
 *
 * The  interactive user interfaces in modified source and object code versions
 * of the Program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU AGPL version 3.
 *
 * Pursuant to Section 7(b) of the License you must retain the original Product
 * logo when distributing the program. Pursuant to Section 7(e) we decline to
 * grant you any rights under trademark law for use of our trademarks.
 *
 * All the Product's GUI elements, including illustrations and icon sets, as
 * well as technical writing content are licensed under the terms of the
 * Creative Commons Attribution-ShareAlike 4.0 International. See the License
 * terms at http://creativecommons.org/licenses/by-sa/4.0/legalcode
 *
 */
 
(function(window, undefined){
	var isInit = false;
	var ifr;
	const isIE = checkInternetExplorer();	//check IE
	var prevTxt;
	var txt;
	var paste_done  = true;
	var translated = '';
	var huskyAutoInsertStarted = false;
	var huskyAutoInsertDone = false;
	
	window.Asc.plugin.init = function(text)
	{
		if (isIE) {
			showMessage("This plugin doesn't work in Internet Explorer.");
			return;
		}
		if (window.Asc.plugin.info.editorType === 'word') {
			var readSelectedText = function() {
				window.Asc.plugin.executeMethod("GetSelectedText", [{Numbering:false}], function(data) {
					prevTxt = txt;
					txt = (!data) ? "" : ProcessText(data);
					if (!txt && getHuskyAutoTranslate()) {
						getWholeDocumentText(function(documentText) {
							txt = ProcessText(documentText || "");
							ExecPlugin();
						});
					} else {
						ExecPlugin();
					}
				});
			};
			if (getHuskyAutoTranslate()) {
				selectWholeDocument(readSelectedText);
			} else {
				readSelectedText();
			}
		} else {
			prevTxt = txt;
			txt = ProcessText(text);
			ExecPlugin();
		}
	};

	function ExecPlugin() {
		if (!isInit) {
			document.getElementById("iframe_parent").innerHTML = "";
			ifr                = document.createElement("iframe");
			ifr.position	   = "fixed";
			ifr.name           = "google_name";
			ifr.id             = "google_id";
			ifr.src            = "./index_widget.html";//?text=" + encodeURIComponent(text);
			ifr.style.top      = "0px";
			ifr.style.left     = "0px";
			ifr.style.width    = "100%";
			ifr.style.height   = "100%";
			ifr.setAttribute("frameBorder", "0");
			document.getElementById("iframe_parent").appendChild(ifr);
			isInit = true;
			ifr.onload = function() {
				if (ifr.contentWindow.document.readyState == 'complete')
					window.Asc.plugin.onThemeChanged(Asc.plugin.theme);
					setTimeout(function() {
						let element = ifr.contentDocument ? ifr.contentDocument.getElementById("google_translate_element") : null;
						if (element) {
							element.innerHTML = escape(txt);
							if (txt.length)
								ifr.contentDocument.getElementById("div_btn").classList.remove("hidden");
						}
					}, 500);

				var selectElement = ifr.contentDocument.getElementsByClassName('goog-te-combo')[0];
				if (!selectElement) {
					// in this case plugin won't work (it can be problem with region)
					showMessage(window.Asc.plugin.tr("This plugin doesn't work in your region."));
					return;
				}
				selectElement.addEventListener('change', function(event) {
					if (txt || ifr.contentDocument.getElementById("google_translate_element").innerHTML) {
						ifr.contentWindow.postMessage("onchange_goog-te-combo", '*');
						ifr.contentDocument.getElementById("google_translate_element").style.opacity = 0;
					}
				});
				ifr.contentDocument.getElementById("google_translate_element").style.height = "fit-content";
				var btn = ifr.contentDocument.createElement("button");
				var btnReplace = ifr.contentDocument.createElement("button");
				var div = ifr.contentDocument.createElement("div");
				var select = ifr.contentDocument.createElement("select");
				select.id = "select_lang";
				select.classList.add("select-lang");
				select.classList.add("goog-te-combo");
				div.appendChild(btn);
				if (!window.Asc.plugin.info.isViewMode)
					div.appendChild(btnReplace);
				div.id = "div_btn";
				div.classList.add("skiptranslate");
				div.classList.add("div_btn");
				div.classList.add("hidden");
				btn.innerHTML = window.Asc.plugin.tr("Copy");
				btn.id = "btn_copy";
				btn.classList.add("btn-text-default");
				btnReplace.classList.add("btn-text-default");
				btnReplace.innerHTML = window.Asc.plugin.tr("Insert");
				btnReplace.id = "btn_replace";
				setTimeout(function() {
					ifr.contentDocument.getElementById("body").appendChild(div);
					ifr.contentDocument.getElementById(":0.targetLanguage").appendChild(select);
				}, 100);

				setTimeout(function() {
					btnReplace.onclick = function () {
						if (!paste_done)
							return;
						else
							paste_done = false;

						var translatedTxt = ifr.contentDocument.getElementById("google_translate_element").outerText;
						var allParasTxt = translatedTxt.split(/\n/);
						var allParsedParas = [];

						for (var nStr = 0; nStr < allParasTxt.length; nStr++) {
							if (allParasTxt[nStr].search(/	/) === 0) {
								allParsedParas.push("");
								allParasTxt[nStr] = allParasTxt[nStr].replace(/	/, "");
							}
							var sSplited = allParasTxt[nStr].split(/	/);

							sSplited.forEach(function(item, i, sSplited) {
								allParsedParas.push(item);
							});
						}
						Asc.scope.arr = allParsedParas;
						window.Asc.plugin.executeMethod("GetVersion", [], function(version) {
							if (version === undefined) {
								window.Asc.plugin.executeMethod("PasteText", [ifr.contentDocument.getElementById("google_translate_element").outerText], function(result) {
									paste_done = true;
								});
							}
							else {
								window.Asc.plugin.executeMethod("GetSelectionType", [], function(sType) {
									switch (sType) {
										case "none":
										case "drawing":
											window.Asc.plugin.executeMethod("PasteText", [ifr.contentDocument.getElementById("google_translate_element").outerText], function(result) {
												paste_done = true;
											});
											break;
										case "text":
											window.Asc.plugin.callCommand(function() {
												Api.ReplaceTextSmart(Asc.scope.arr);
											}, undefined, undefined, function(result) {
												paste_done = true;
											});
											break;
									}
								});
							}
						});
					}
					scheduleHuskyAutoInsert(btnReplace);
				});
				ifr.contentWindow.postMessage("update_scroll", '*');
				ifr.contentWindow.postMessage({type: 'translate', text: translated}, '*')
			}
		} else if(prevTxt != txt) {
			ifr.contentWindow.postMessage(txt, '*');
			ifr.contentDocument.getElementById("google_translate_element").style.opacity = 0;
		}
	};
	function ProcessText(sText) {
		sText = sText || "";
		return sText.replace(/	/gi, '\n').replace(/	/gi, '\n');
	};

	function getHuskyAutoTranslate() {
		try {
			return localStorage.getItem("husky_auto_translate") === "1";
		} catch (e) {
			return false;
		}
	}

	function normalizeHuskyText(value) {
		return String(value || "").replace(/\s+/g, " ").trim();
	}

	function selectWholeDocument(callback) {
		var called = false;
		function done() {
			if (called) return;
			called = true;
			if (callback) callback();
		}
		try {
			if (window.Asc && Asc.plugin && typeof Asc.plugin.executeMethod === "function") {
				Asc.plugin.executeMethod("SelectAll", [], function() {
					setTimeout(done, 200);
				});
				setTimeout(done, 1200);
				return;
			}
		} catch (e) {}
		try {
			if (window.Asc && Asc.plugin && typeof Asc.plugin.callCommand === "function") {
				Asc.plugin.callCommand(function() {
					var doc = Api.GetDocument();
					if (doc && typeof doc.SelectAll === "function") {
						doc.SelectAll();
						return true;
					}
					return false;
				}, false, true, function() {
					setTimeout(done, 200);
				});
				setTimeout(done, 1200);
				return;
			}
		} catch (e) {}
		done();
	}

	function scheduleHuskyAutoInsert(btnReplace) {
		if (!getHuskyAutoTranslate() || huskyAutoInsertStarted || !btnReplace) return;
		if (window.Asc.plugin.info.isViewMode) return;
		huskyAutoInsertStarted = true;
		var startedAt = Date.now();
		var sourceText = normalizeHuskyText(txt);
		function tick() {
			if (huskyAutoInsertDone) return;
			if (!ifr || !ifr.contentDocument || !paste_done) {
				setTimeout(tick, 500);
				return;
			}
			var element = ifr.contentDocument.getElementById("google_translate_element");
			var divBtn = ifr.contentDocument.getElementById("div_btn");
			var translatedText = normalizeHuskyText(element ? element.outerText : "");
			var visible = !!element && element.style.opacity !== "0";
			var buttonsVisible = !!divBtn && !divBtn.classList.contains("hidden");
			var changed = translatedText && (!sourceText || translatedText !== sourceText);
			var timedOutWithText = translatedText && Date.now() - startedAt > 45000;
			if (visible && buttonsVisible && (changed || timedOutWithText)) {
				huskyAutoInsertDone = true;
				selectWholeDocument(function() {
					setTimeout(function() {
						try {
							btnReplace.click();
						} catch (e) {}
					}, 300);
				});
				return;
			}
			if (Date.now() - startedAt < 90000) {
				setTimeout(tick, 500);
			}
		}
		setTimeout(tick, 1000);
	}

	function getWholeDocumentText(callback) {
		try {
			window.Asc.plugin.callCommand(function() {
				var doc = Api.GetDocument();
				if (!doc || typeof doc.GetAllParagraphs !== "function") return "";
				var paragraphs = doc.GetAllParagraphs() || [];
				var lines = [];
				for (var i = 0; i < paragraphs.length; i++) {
					var paragraph = paragraphs[i];
					if (!paragraph || typeof paragraph.GetText !== "function") continue;
					var line = paragraph.GetText({ Numbering: false }) || "";
					if (line) lines.push(line);
				}
				return lines.join("\n");
			}, false, true, function(result) {
				callback(result || "");
			});
		} catch (e) {
			callback("");
		}
	}

	function checkInternetExplorer(){
		var rv = -1;
		if (window.navigator.appName == 'Microsoft Internet Explorer') {
			const ua = window.navigator.userAgent;
			const re = new RegExp('MSIE ([0-9]{1,}[\.0-9]{0,})');
			if (re.exec(ua) != null) {
				rv = parseFloat(RegExp.$1);
			}
		} else if (window.navigator.appName == 'Netscape') {
			const ua = window.navigator.userAgent;
			const re = new RegExp('Trident/.*rv:([0-9]{1,}[\.0-9]{0,})');

			if (re.exec(ua) != null) {
				rv = parseFloat(RegExp.$1);
			}
		}
		return rv !== -1;
	};

	function showMessage(message) {
		document.getElementById("iframe_parent").innerHTML = "<h4 id='h4' style='margin:5px'>" + message + "</h4>";
	};

	window.Asc.plugin.button = function(id)
	{
		this.executeCommand("close", "");
	};

	window.onresize = function()
	{
		ifr && ifr.contentWindow.postMessage("update_scroll", '*');
	};

	window.Asc.plugin.onExternalMouseUp = function()
	{
		var evt = document.createEvent("MouseEvents");
		evt.initMouseEvent("mouseup", true, true, window, 1, 0, 0, 0, 0,
			false, false, false, false, 0, null);

		document.dispatchEvent(evt);
	};

	window.Asc.plugin.onTranslate = function()
	{
		var field = document.getElementById("h4");
		if (field)
			field.innerHTML = window.Asc.plugin.tr(field.innerText);

		translated = window.Asc.plugin.tr('Select Language');
	};
	window.Asc.plugin.onThemeChanged = function(theme)
	{
		window.Asc.plugin.onThemeChangedBase(theme);
		var style = document.getElementsByTagName('head')[0].lastChild;
		if (ifr && ifr.contentWindow)
			setTimeout( function() { ifr.contentDocument && ifr.contentWindow.postMessage({type: 'themeChanged', theme: theme, style: style.innerHTML}, '*' ) } ,600 );
	};
	
})(window, undefined);
